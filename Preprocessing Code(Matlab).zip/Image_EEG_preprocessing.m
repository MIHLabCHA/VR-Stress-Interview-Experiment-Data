
loadfpath_eeg='\\166.104.138.158\teamNE\20_Projects\2022\미래뇌융합\01_Data\03_EEG\Session\';
loadfpath_log='\\166.104.138.158\teamNE\20_Projects\2022\미래뇌융합\01_Data\01_Self_report\ver2\';

sublist_filename='\\166.104.138.158\teamNE\20_Projects\2022\미래뇌융합\01_Data\Subject 정리(ver.22.06).xlsx';
sublist=readcell(sublist_filename);
subname=sublist(11:40,5);
subdate=sublist(11:40,4);
subidx =sublist(11:40,1);

fs_btone=500;
locutoff=1;
hicutoff=50;

%%
lowfreq=6;
highfreq=12;
freqbin=1;
%% Hyper parameters
epochlength=30; %[sec]
overlap=0.5; % 0~1
%gsr frequency band: DC~20Hz
logpower_total=[];
%% Load EEG
for fileidx=1:length(subidx)
    %% Resting
    loadfname=strcat(subname{fileidx},'_eeg_pre.mat');
    try
        load(strcat(loadfpath_eeg,loadfname));
    catch
        continue
    end
    Resting_filtered=bandpass(file2save_resting,[1,50],fs_btone);

    %% Epoch num calculation
    epochnum=floor((length(Resting_filtered)-epochlength*fs_btone)/(epochlength*(1-overlap)*fs_btone))+1;
    
    %%
    clearvars data_epoch logpower_flip_baseline logpower_flip_submean
    
    for epochidx=1:epochnum
        epochstart=1+(epochidx-1)*epochlength*fs_btone*(1-overlap);
        epochend=epochstart+epochlength*fs_btone-1;
        data_epoch(epochidx,:)=Resting_filtered(epochstart:epochend);
        [s,freq,time,ps]=spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],lowfreq:freqbin:highfreq,fs_btone);
        logpower=10*log10(ps);
        logpower_flip_baseline(:,:,epochidx)=flip(logpower,1);
        close all
    end

    %% S1
    loadfname=strcat(subname{fileidx},'_eeg_S1.mat');
    try
        load(strcat(loadfpath_eeg,loadfname));
    catch
        continue
    end
    S1_filtered=bandpass(file2save_session1,[1,50],fs_btone);

    %% Epoch num calculation
    epochnum=floor((length(S1_filtered)-epochlength*fs_btone)/(epochlength*(1-overlap)*fs_btone))+1;
    
    %%
    clearvars data_epoch logpower_flip_S1 logpower_flip_submean
    
    for epochidx=1:epochnum
        epochstart=1+(epochidx-1)*epochlength*fs_btone*(1-overlap);
        epochend=epochstart+epochlength*fs_btone-1;
        data_epoch(epochidx,:)=S1_filtered(epochstart:epochend);
%         figure;spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],1:30,fs_btone,'yaxis');
%         colormap('gray')
        [s,freq,time,ps]=spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],lowfreq:freqbin:highfreq,fs_btone);
        logpower=10*log10(ps);
        logpower_flip_S1(:,:,epochidx)=flip(logpower,1);
        close all
    end

    %% S2
    loadfname=strcat(subname{fileidx},'_eeg_S2.mat');
    try
        load(strcat(loadfpath_eeg,loadfname));
    catch
        continue
    end
    S2_filtered=bandpass(file2save_session2,[1,50],fs_btone);

    %% Epoch num calculation
    epochnum=floor((length(S2_filtered)-epochlength*fs_btone)/(epochlength*(1-overlap)*fs_btone))+1;
    
    %%
    clearvars data_epoch logpower_flip_S2 logpower_flip_submean
    
    for epochidx=1:epochnum
        epochstart=1+(epochidx-1)*epochlength*fs_btone*(1-overlap);
        epochend=epochstart+epochlength*fs_btone-1;
        data_epoch(epochidx,:)=S2_filtered(epochstart:epochend);
%         figure;spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],1:30,fs_btone,'yaxis');
%         colormap('gray')
        [s,freq,time,ps]=spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],lowfreq:freqbin:highfreq,fs_btone); 
        logpower=10*log10(ps);
        logpower_flip_S2(:,:,epochidx)=flip(logpower,1);
        close all
    end
    logpower_flip=cat(3,logpower_flip_baseline,logpower_flip_S1,logpower_flip_S2);
    logpower_total=cat(3,logpower_total,logpower_flip);
end

logpower_grandmean=mean(logpower_total,3);
imageset_mu = mean(logpower_grandmean,'all');
imageset_sd =  std(logpower_grandmean,[],'all');

logpower_meansubtract=logpower_total-repmat(logpower_grandmean,1,1,2151);

logpower_min=min(logpower_meansubtract,[],'all');
logpower_max=max(logpower_meansubtract,[],'all');

totalimage=mat2gray(logpower_meansubtract,[logpower_min logpower_max]);
imageset_mu = mean(totalimage,'all');
imageset_sd =  std(totalimage,[],'all');
for fileidx=1:length(subidx)
    %% Resting
    loadfname=strcat(subname{fileidx},'_eeg_pre.mat');
    try
        load(strcat(loadfpath_eeg,loadfname));
    catch
        continue
    end
    Resting_filtered=bandpass(file2save_resting,[1,50],fs_btone);

    %% Epoch num calculation
    epochnum=floor((length(Resting_filtered)-epochlength*fs_btone)/(epochlength*(1-overlap)*fs_btone))+1;
    
    %%
    clearvars data_epoch logpower_flip logpower_flip_submean
    
    for epochidx=1:epochnum
        epochstart=1+(epochidx-1)*epochlength*fs_btone*(1-overlap);
        epochend=epochstart+epochlength*fs_btone-1;
        data_epoch(epochidx,:)=Resting_filtered(epochstart:epochend);
%         figure;spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],1:30,fs_btone,'yaxis');
%         colormap('gray')
        [s,freq,time,ps]=spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],lowfreq:freqbin:highfreq,fs_btone);
        logpower=10*log10(ps);
        logpower_flip(:,:,epochidx)=flip(logpower,1);

        close all

    end
    logpower_flip_meansubtract=logpower_flip-logpower_grandmean;
    for epochtemp=1:size(logpower_flip_meansubtract,3)
        im_temp=mat2gray(logpower_flip_meansubtract(:,:,epochtemp),[logpower_min logpower_max]); %15*59 > 420*413
        im_temp_reshape=repmat(reshape(im_temp,[size(im_temp),1]),1,1,3); % 3ch
        im_temp_resize =imresize(im_temp_reshape,[64 64],"nearest");
        imwrite(im_temp_resize,strcat('\\166.104.138.158\teamNE\08_AI\Deeplearning\04_Data\Image\EEG\230405\Normal\',num2str(fileidx),'_',num2str(epochtemp),'.jpg'))
    end

    %% S1
    loadfname=strcat(subname{fileidx},'_eeg_S1.mat');
    try
        load(strcat(loadfpath_eeg,loadfname));
    catch
        continue
    end
    S1_filtered=bandpass(file2save_session1,[1,50],fs_btone);

    %% Epoch num calculation
    epochnum=floor((length(S1_filtered)-epochlength*fs_btone)/(epochlength*(1-overlap)*fs_btone))+1;
    
    %%
    clearvars data_epoch logpower_flip logpower_flip_submean
    
    for epochidx=1:epochnum
        epochstart=1+(epochidx-1)*epochlength*fs_btone*(1-overlap);
        epochend=epochstart+epochlength*fs_btone-1;
        data_epoch(epochidx,:)=S1_filtered(epochstart:epochend);
%         figure;spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],1:30,fs_btone,'yaxis');
%         colormap('gray')
        [s,freq,time,ps]=spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],lowfreq:freqbin:highfreq,fs_btone);
        logpower=10*log10(ps);
        logpower_flip(:,:,epochidx)=flip(logpower,1);

        close all

    end
    logpower_flip_meansubtract=logpower_flip-logpower_grandmean;
    for epochtemp=1:size(logpower_flip_meansubtract,3)
        im_temp=mat2gray(logpower_flip_meansubtract(:,:,epochtemp),[logpower_min logpower_max]);
        im_temp_reshape=repmat(reshape(im_temp,[size(im_temp),1]),1,1,3); % 3ch
        im_temp_resize =imresize(im_temp_reshape,[64 64],"nearest");
        imwrite(im_temp_resize,strcat('\\166.104.138.158\teamNE\08_AI\Deeplearning\04_Data\Image\EEG\230405\Stress\',num2str(fileidx),'_',num2str(epochtemp),'.jpg'))
    end
    numofS1=epochtemp;
    %% S2
    loadfname=strcat(subname{fileidx},'_eeg_S2.mat');
    try
        load(strcat(loadfpath_eeg,loadfname));
    catch
        continue
    end
    S2_filtered=bandpass(file2save_session2,[1,50],fs_btone);

    %% Epoch num calculation
    epochnum=floor((length(S2_filtered)-epochlength*fs_btone)/(epochlength*(1-overlap)*fs_btone))+1;
    
    %%
    clearvars data_epoch logpower_flip logpower_flip_submean
    
    for epochidx=1:epochnum
        epochstart=1+(epochidx-1)*epochlength*fs_btone*(1-overlap);
        epochend=epochstart+epochlength*fs_btone-1;
        data_epoch(epochidx,:)=S2_filtered(epochstart:epochend);
%         figure;spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],1:30,fs_btone,'yaxis');
%         colormap('gray')
        [s,freq,time,ps]=spectrogram(data_epoch(epochidx,:),epochlength*fs_btone/30,[],lowfreq:freqbin:highfreq,fs_btone);
        logpower=10*log10(ps);
        logpower_flip(:,:,epochidx)=flip(logpower,1);

        close all

    end

    logpower_flip_meansubtract=logpower_flip-logpower_grandmean;
    for epochtemp=1:size(logpower_flip_meansubtract,3)
        im_temp=mat2gray(logpower_flip_meansubtract(:,:,epochtemp),[logpower_min logpower_max]);
        im_temp_reshape=repmat(reshape(im_temp,[size(im_temp),1]),1,1,3); % 3ch
        im_temp_resize =imresize(im_temp_reshape,[64 64],"nearest");
        imwrite(im_temp_resize,strcat('\\166.104.138.158\teamNE\08_AI\Deeplearning\04_Data\Image\EEG\230405\Stress\',num2str(fileidx),'_',num2str(epochtemp+numofS1),'.jpg'))
    end
end