## GPU setting
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

savename = '2023-01-02_GSR_1Fold'

# Making Log folder
from datetime import datetime
now = datetime.now()
now = f'{now}'
now = now[:19]
print("Today Now : ", now)

path = '/home/gnsruatkfkd/FutureBrain4/Code/Log'
if not os.path.isdir(path + f'/{now}_' + f'{savename}'):
    os.mkdir(path + f'/{now}_' + f'{savename}')
savepath = path + f'/{now}_' + f'{savename}'



# Making Log txt
import sys
import csv
f = open(savepath + '/LogData.txt', 'w')
cf = open(savepath + f'/{savename}.csv', 'w')

print(f'{savename}', file = f)

import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import KFold
import random

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.nn import functional as F
from torch.optim import lr_scheduler
import torchvision
from torchvision import datasets, transforms
import torchvision.transforms as transforms

import glob
from sklearn.metrics import confusion_matrix, roc_auc_score



# Define dataset class
from PIL import Image
class MyDataset(torch.utils.data.Dataset):
    """
    Attributes
    ----------
    img_list : list of image path
    label_list : list of label path
    phase : 'train' or 'val'
    """
    
    def __init__(self, img_list, label_list, phase, transform):
        self.img_list = img_list
        self.label_list = label_list
        self.phase = phase # select train or val
        self.transform = transform # transform image
        
    def __len__(self):
        '''return number of images'''
        return len(self.img_list)
    
    def __getitem__(self, index):
        '''return preprocessed image and label'''
        image_path = self.img_list[index]
        img = Image.open(image_path)
        
        transformed_img = self.transform(img, self.phase)
        label = self.label_list[index]
        
        return transformed_img, label



# Define transform class
from torchvision import models, transforms

class MyTransform():
    """
    Attributes
    ----------
    resize : int
        width / height value after transform
    mean : (R, G, B)
        mean of each chennel
    std : (R, G, B)
        std of each chennel
    """
    def __init__(self, resize, mean, std):
        self.data_transform = {
            'train' : transforms.Compose([
                transforms.Resize(resize),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ]),
            'val' : transforms.Compose([
                transforms.Resize(resize),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ])
        }
    
    def __call__(self, img, phase = 'train'):
        """
        Parameters
        --------
        phase : 'train' or 'val'
        """
        return self.data_transform[phase](img)
    


## Data load
size = 224 # 224   384
mean = (0.5331, 0.5331, 0.5331)
std = (0.095647)
batch_size = 32
n_epochs = 30
learning_rate = 0.001

print('\nInput data information',file = f)
print('Size : ', size, file = f)
print('Mean : ', mean, file = f)
print('Std : ', std, file = f)
print('\nParameter', file = f)
print('Batch size : ', batch_size, file = f)
print('Epochs : ', n_epochs, file = f)
print('Learning rate : ', learning_rate, file = f)

## Make dataset
Subject_list = list(range(1, 30)) # 29 subjects
Normal_data_path = 'StressDataset/GSR/Normal/'
Stress_data_path = 'StressDataset/GSR/Stress/'

## Class weight
tmp_Normal = glob.glob(f"{Normal_data_path}/*.jpg")
tmp_Stress = glob.glob(f"{Stress_data_path}/*.jpg")
Normal_weight = 1 - (len(tmp_Normal) / (len(tmp_Normal) + len(tmp_Stress)))
Stress_weight = 1 - (len(tmp_Stress) / (len(tmp_Normal) + len(tmp_Stress)))
class_weights = torch.FloatTensor([Normal_weight, Stress_weight]).cuda()


## Model setting
import timm
num_classes = 2 
# vit_base_patch16_384 # resnet50 # vgg16 inception_v3 resnet152 densenet161 efficientnet_b0
model_name = 'resnet152'
model = timm.create_model(model_name, pretrained = False, num_classes = num_classes)
device = torch.device("cuda:0" if torch.cuda.is_available() else 'cpu')
model = model.to(device)
model_cam = model

print('\nmodel : ', model_name, file = f)


criterion = nn.CrossEntropyLoss(weight = class_weights)
optimizer = optim.Adam(model.parameters(), lr = learning_rate)
exp_lr_scheduler = lr_scheduler.StepLR(optimizer, step_size = 10, gamma = 0.1)

print('\nCriterion : ', criterion, file = f)
print('\nOptimizer : ', optimizer, file = f)
print('\nLr_scheduler.StepLR', file = f)
print('Step_size : ', exp_lr_scheduler.step_size, file = f)
print('Gamma : ', exp_lr_scheduler.gamma, file = f)
print('\n', file = f)

## Time calculate
from pytictoc import TicToc
t = TicToc()
t.tic() #start time

## Make train,test img list and label list
tmp_file_list1 = glob.glob(f'{savename}/Train/Normal/*.jpg')
tmp_file_list2 = glob.glob(f'{savename}/Train/Stress/*.jpg')
tmp_file_list3 = glob.glob(f'{savename}/Test/Normal/*.jpg')
tmp_file_list4 = glob.glob(f'{savename}/Test/Stress/*.jpg')

train_img_list = tmp_file_list1 + tmp_file_list2
tmp_TrainNormal_label_list = [0] * len(tmp_file_list1)
tmp_TrainStress_label_list = [1] * len(tmp_file_list2)
train_label_list = tmp_TrainNormal_label_list + tmp_TrainStress_label_list

test_img_list = tmp_file_list3 + tmp_file_list4
tmp_TestNormal_label_list = [0] * len(tmp_file_list3)
tmp_TestStress_label_list = [1] * len(tmp_file_list4)
test_label_list = tmp_TestNormal_label_list + tmp_TestStress_label_list



## For result
best_n_epoch = 0
best_accuracy = 0.0
best_auroc = 0.0
y_auroc = list(range(n_epochs))

   
## Train loop
for epoch in range(n_epochs):
    print('Epoch {}'.format(epoch + 1))
    print('--------------------')
  
    # Make dataset!    
    train_dataset = MyDataset(img_list = train_img_list, label_list = train_label_list,
                              phase = 'train', transform = MyTransform(size, mean, std))
    val_dataset = MyDataset(img_list = test_img_list, label_list = test_label_list,
                              phase = 'val', transform = MyTransform(size, mean, std))
    
    image_datasets = {'train' : train_dataset, 'val' : val_dataset}
    dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}
        
    # DataLoader
    train_dataloader = torch.utils.data.DataLoader(
        train_dataset, batch_size = batch_size, shuffle = True, drop_last = True)
    val_dataloader = torch.utils.data.DataLoader(
        val_dataset, batch_size = batch_size, shuffle = False)
    
    dataloaders_dict = {'train' : train_dataloader, 'val' : val_dataloader}
    
    # Train loop
    for phase in ['train', 'val']:
        if phase == 'train':
            model.train()
        else:
            model.eval()
            
        running_loss = 0.0
        running_corrects = 0
        running_CM = 0
        acc_std = 0
        auroc_std = 0
        running_auc_label = []
        running_auc_preds = []
        
        
        for inputs, labels in dataloaders_dict[phase]:
            inputs = inputs.to(device)
            labels = labels.to(device)
            
            optimizer.zero_grad()
            
            with torch.set_grad_enabled(phase == 'train'):
                outputs = model(inputs)
                preds = F.softmax(outputs, dim = 1)
                preds = preds[:,1]
                #_, preds = torch.max(outputs, 1)
                _, prediction = torch.max(outputs, 1)
                loss = criterion(outputs, labels)                  
                
                if phase == 'train':
                    loss.backward()
                    optimizer.step()
                
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(prediction == labels.data)
            
            list_labels = labels.tolist()
            list_preds = preds.tolist()
            running_auc_label += list_labels
            running_auc_preds += list_preds
          
            
          
        if phase == 'train':
            exp_lr_scheduler.step()
            
        epoch_loss = running_loss / dataset_sizes[phase]
        epoch_acc = running_corrects.double() / dataset_sizes[phase]
        
        # auc roc
        list_labels = torch.tensor(running_auc_label)
        list_preds = torch.tensor(running_auc_preds)
        running_auc_score = roc_auc_score(list_labels.cpu(), list_preds.cpu())
        y_auroc[epoch] = running_auc_score
        
        torch.save(model.state_dict(), savepath + f'/{savename}' + f'Epoch{epoch+1}' + '_weights.pth')
        torch.save(model, savepath + f'/{savename}' + f'Epoch{epoch+1}' + '_whole.pt')

        
        print('{} Loss : {:.4f} Acc : {:.4f}'.format(phase, epoch_loss, epoch_acc))
        #print(labels)
        #print(preds)
        print('Epoch AUROC : ', running_auc_score)
        
        if phase == 'val' and running_auc_score > best_auroc:
            best_epoch = epoch+1
            best_auroc = running_auc_score
            best_accuracy = epoch_acc
            #torch.save(model.state_dict(), savepath + f'/{savename}' +'_weights.pth')
            #pth_name = f'/{savename}' +'_weights.pth'
    

t.toc() # end time
trainingTime = t.tocvalue()

print('\n best epoch : {}   best acc : {:.4f}'.format(best_epoch, best_accuracy), file = f)
print('best AUROC : {}'.format(best_auroc), file = f)
print('Whole training time : {}'.format(trainingTime), file = f)
print('\n', file = f)
        
## Result AUROC plot
x = list(range(1, n_epochs+1)) # x = epoch
plt.figure(figsize = (10, 10))
plt.plot(x, y_auroc, '-')
plt.plot(best_epoch, best_auroc, 'o')
plt.xlabel('Epoch')
plt.ylabel('AUROC score')
plt.savefig(savepath + '/AUROC_' + f'{savename}.png')
plt.show    
    

wr = csv.writer(cf)
wr.writerow(['Auroc'])
for q in range(len(y_auroc)):
    wr.writerow([y_auroc[q]])


f.close()
cf.close()




















