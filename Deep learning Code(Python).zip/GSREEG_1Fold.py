## GPU setting
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

savename = '2023-01-02_GSREEG_1Fold'
savename_1 = '2023-01-02_GSR_1Fold'
savename_2 = '2023-01-02_EEG_1Fold'



# Making Log folder
from datetime import datetime
now = datetime.now()
now = f'{now}'
now = now[:19]
print("Today Now : ", now)

path = '/home/gnsruatkfkd/FutureBrain4/Code/Log'
if not os.path.isdir(path + f'/{now}_' + f'{savename}'):
    os.mkdir(path + f'/{now}_' + f'{savename}')
savepath = path + f'/{now}_' + f'{savename}'

    
# Making Log txt
import sys
import csv
f = open(savepath + '/LogData.txt', 'w')
cf = open(savepath + f'/{savename}.csv', 'w')

print(f'{savename}', file = f)

import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import KFold
import random

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.nn import functional as F
from torch.optim import lr_scheduler
import torchvision
from torchvision import datasets, transforms
import torchvision.transforms as transforms

import glob
from sklearn.metrics import confusion_matrix, roc_auc_score



# Define dataset class
from PIL import Image
class MyDataset(torch.utils.data.Dataset):
    """
    Attributes
    ----------
    img_list : list of image path
    label_list : list of label path
    phase : 'train' or 'val'
    """
    
    def __init__(self, img_list, label_list, phase, transform):
        self.img_list = img_list
        self.label_list = label_list
        self.phase = phase # select train or val
        self.transform = transform # transform image
        
    def __len__(self):
        '''return number of images'''
        return len(self.img_list)
    
    def __getitem__(self, index):
        '''return preprocessed image and label'''
        image_path = self.img_list[index]
        img = Image.open(image_path)
        
        transformed_img = self.transform(img, self.phase)
        label = self.label_list[index]
        
        return transformed_img, label



# Define transform class
from torchvision import models, transforms

class MyTransform():
    """
    Attributes
    ----------
    resize : int
        width / height value after transform
    mean : (R, G, B)
        mean of each chennel
    std : (R, G, B)
        std of each chennel
    """
    def __init__(self, resize, mean, std):
        self.data_transform = {
            'train' : transforms.Compose([
                transforms.Resize(resize),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ]),
            'val' : transforms.Compose([
                transforms.Resize(resize),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ])
        }
    
    def __call__(self, img, phase = 'train'):
        """
        Parameters
        --------
        phase : 'train' or 'val'
        """
        return self.data_transform[phase](img)
    
    
class MyEnsemble(nn.Module):
    def __init__(self, fe_model1, fe_model2):
        super(MyEnsemble, self).__init__()
        self.fc1 = nn.Linear(4096, 8)
        self.ReLU = nn.ReLU()
        self.fc2 = nn.Linear(8, 2, bias=True)
        self.GAP = nn.AdaptiveAvgPool2d(1)
        self.flatten = nn.Flatten(1) 
        self.dropout = nn.Dropout(0.5)
        self.initialize_weights()
        
        self.modelA = fe_model1
        self.modelB = fe_model2
        
    def forward(self, x1, x2):
        x1 = self.modelA(x1)
        x2 = self.modelB(x2)
        x1 = x1[4]
        x2 = x2[4]
        x = torch.cat((x1, x2), dim = 1)
        x = self.GAP(x)
        x = self.flatten(x)
        x = self.fc1(x)       
        x = self.ReLU(x)
        x = self.dropout(x)
        x = self.fc2(x)

        return x
    
    def initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight)
                
                if m.bias is not None:
                    nn.init.constant_(m.weight)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight)
                nn.init.constant_(m.bias, 0)
    




## Ato model
import timm
# efficientnet_b0 resnet152 resnet50 vit_base_patch16_384 inception_v3 densenet161
model_name = 'resnet50'
#fe_model = timm.create_model(model_name, features_only = True, pretrained = True)
#model = timm.create_model(model_name, pretrained = True, num_classes = 2)

# fe_model1 = timm.create_model(model_name, features_only = True, pretrained=True) #GSR
# fe_model2 = timm.create_model(model_name, features_only = True, pretrained=True) #EEG    
fe_model1 = timm.create_model(model_name, features_only = True) #GSR
fe_model2 = timm.create_model(model_name, features_only = True) #EEG     
fe_model1.load_state_dict(torch.load('2023-01-02_GSR_1FoldEpoch5_weights.pth'), strict=False)
fe_model2.load_state_dict(torch.load('2023-01-02_EEG_1FoldEpoch10_weights.pth'), strict=False)

## Data load
size = 224

mean_1 = (0.5331, 0.5331, 0.5331) # GSR
std_1 = (0.095647)
mean_2 = (0.6832, 0.6832, 0.6832) # EEG
std_2 = (0.0842)

batch_size = 32
n_epochs = 30
learning_rate = 0.001

print('\nInput data information',file = f)
print('Size : ', size, file = f)
print('GSR Mean : ', mean_1, file = f)
print('GSR Std : ', std_1, file = f)
print('EEG Mean : ', mean_2, file = f)
print('EEG Std : ', std_2, file = f)
print('\nParameter', file = f)
print('Batch size : ', batch_size, file = f)
print('Epochs : ', n_epochs, file = f)
print('Learning rate : ', learning_rate, file = f)

## Make dataset
Subject_list = list(range(1, 30)) # 29 subjects
Normal_data_path = 'StressDataset/GSR/Normal/'
Stress_data_path = 'StressDataset/GSR/Stress/'

## Class weight
tmp_Normal = glob.glob(f"{Normal_data_path}/*.jpg")
tmp_Stress = glob.glob(f"{Stress_data_path}/*.jpg")
Normal_weight = 1 - (len(tmp_Normal) / (len(tmp_Normal) + len(tmp_Stress)))
Stress_weight = 1 - (len(tmp_Stress) / (len(tmp_Normal) + len(tmp_Stress)))
class_weights = torch.FloatTensor([Normal_weight, Stress_weight]).cuda()

print('\nmodel : ', model_name, file = f)

device = torch.device("cuda:0" if torch.cuda.is_available() else 'cpu')
model = MyEnsemble(fe_model1, fe_model2)
model = model.to(device)


criterion = nn.CrossEntropyLoss(weight = class_weights)
optimizer = optim.Adam(model.parameters(), lr = learning_rate)
exp_lr_scheduler = lr_scheduler.StepLR(optimizer, step_size = 10, gamma = 0.1)

print('\nCriterion : ', criterion, file = f)
print('\nOptimizer : ', optimizer, file = f)
print('\nLr_scheduler.StepLR', file = f)
print('Step_size : ', exp_lr_scheduler.step_size, file = f)
print('Gamma : ', exp_lr_scheduler.gamma, file = f)
print('\n', file = f)

## Time calculate
from pytictoc import TicToc
t = TicToc()
t.tic() #start time

## GSR
## Make train,test img list and label list
tmp_file_list1 = glob.glob(f'{savename_1}/Train/Normal/*.jpg')
tmp_file_list2 = glob.glob(f'{savename_1}/Train/Stress/*.jpg')
tmp_file_list3 = glob.glob(f'{savename_1}/Test/Normal/*.jpg')
tmp_file_list4 = glob.glob(f'{savename_1}/Test/Stress/*.jpg')

train_img_list_GSR = tmp_file_list1 + tmp_file_list2
tmp_TrainNormal_label_list = [0] * len(tmp_file_list1)
tmp_TrainStress_label_list = [1] * len(tmp_file_list2)
train_label_list_GSR = tmp_TrainNormal_label_list + tmp_TrainStress_label_list

test_img_list_GSR = tmp_file_list3 + tmp_file_list4
tmp_TestNormal_label_list = [0] * len(tmp_file_list3)
tmp_TestStress_label_list = [1] * len(tmp_file_list4)
test_label_list_GSR = tmp_TestNormal_label_list + tmp_TestStress_label_list

## EEG
## Make train,test img list and label list
tmp_file_list5 = glob.glob(f'{savename_2}/Train/Normal/*.jpg')
tmp_file_list6 = glob.glob(f'{savename_2}/Train/Stress/*.jpg')
tmp_file_list7 = glob.glob(f'{savename_2}/Test/Normal/*.jpg')
tmp_file_list8 = glob.glob(f'{savename_2}/Test/Stress/*.jpg')

train_img_list_EEG = tmp_file_list5 + tmp_file_list6
tmp_TrainNormal_label_list = [0] * len(tmp_file_list5)
tmp_TrainStress_label_list = [1] * len(tmp_file_list6)
train_label_list_EEG = tmp_TrainNormal_label_list + tmp_TrainStress_label_list

test_img_list_EEG = tmp_file_list7 + tmp_file_list8
tmp_TestNormal_label_list = [0] * len(tmp_file_list7)
tmp_TestStress_label_list = [1] * len(tmp_file_list8)
test_label_list_EEG = tmp_TestNormal_label_list + tmp_TestStress_label_list

## For result
best_n_epoch = 0
best_accuracy = 0.0
best_auroc = 0.0
y_auroc = list(range(n_epochs))

class cat_dataloaders():
    def __init__(self, dataloaders):
        self.dataloaders = dataloaders
        len(self.dataloaders)
    def __iter__(self):
        self.loader_iter = []
        for data_loader in self.dataloaders:
            self.loader_iter.append(iter(data_loader))
        return self
    def __next__(self):
        out = []
        for data_iter in self.loader_iter:
            out.append(next(data_iter))
        return tuple(out)

class ConcatDataset(torch.utils.data.Dataset):
    def __init__(self, *datasets):
        self.datasets = datasets
    
    def __getitem__(self, i):
        return tuple(d[i] for d in self.datasets)
    
    def __len__(self):
        return min(len(d) for d in self.datasets)

from itertools import cycle    
  
## Train loop
for epoch in range(n_epochs):
    print('Epoch {}'.format(epoch + 1))
    print('--------------------')
    
    # Make dataset!    
    train_dataset_GSR = MyDataset(img_list = train_img_list_GSR, label_list = train_label_list_GSR,
                              phase = 'train', transform = MyTransform(size, mean_1, std_1))
    val_dataset_GSR = MyDataset(img_list = test_img_list_GSR, label_list = test_label_list_GSR,
                              phase = 'val', transform = MyTransform(size, mean_1, std_1))
    
    train_dataset_EEG = MyDataset(img_list = train_img_list_EEG, label_list = train_label_list_EEG,
                              phase = 'train', transform = MyTransform(size, mean_2, std_2))
    val_dataset_EEG = MyDataset(img_list = test_img_list_EEG, label_list = test_label_list_EEG,
                              phase = 'val', transform = MyTransform(size, mean_2, std_2))
    
    train_dataloader = torch.utils.data.DataLoader(
            ConcatDataset(
                    train_dataset_GSR, train_dataset_EEG
            ),
            batch_size = batch_size, shuffle = True, drop_last=True
        )
    
    val_dataloader = torch.utils.data.DataLoader(
            ConcatDataset(
                    val_dataset_GSR, val_dataset_EEG
            ),
            batch_size = batch_size, shuffle = False
        )
    
    #for i, (train_gsr, train_eeg) in enumerate(train_dataloader):
        #print(train_gsr)
        #print(train_eeg)
    
    image_datasets = {'train' : train_dataset_GSR, 'val' : val_dataset_GSR} # = train_dataset_eeg
    dataset_sizes = {x: len(image_datasets[x]) for x in ['train', 'val']}

    dataloaders_dict = {'train' : train_dataloader, 'val' : val_dataloader}


    # Train loop
    for phase in ['train', 'val']:
        if phase == 'train':
            model.train()
        else:
            model.eval()
            
        running_loss = 0.0
        running_corrects = 0
        running_CM = 0
        acc_std = 0
        auroc_std = 0
        running_auc_label = []
        running_auc_preds = []
        
        
        for GSR, EEG in dataloaders_dict[phase]:
#        for item1, item2 in zip(dataloaders_dict_GSR[phase], dataloaders_dict_EEG[phase]):
#            tmp_image1, tmp_label1 = item1
#            tmp_image2, tmp_label2 = item2
            inputs_GSR = GSR[0]
            inputs_EEG = EEG[0]
            inputs_labels = GSR[1] # EEG[1]
            
            inputs_GSR = inputs_GSR.to(device)
            inputs_EEG = inputs_EEG.to(device)
            inputs_labels = inputs_labels.to(device)
            
            optimizer.zero_grad()
            
            with torch.set_grad_enabled(phase == 'train'):
                outputs = model(inputs_GSR, inputs_EEG)
                #_, preds = torch.max(outputs, 1)
                preds = F.softmax(outputs, dim = 1)
                preds = preds[:,1]
                _, prediction = torch.max(outputs, 1)
                
                loss = criterion(outputs, inputs_labels)
                '''
                running_CM += confusion_matrix(labels.cpu(), preds.cpu(), inputs_labels = [1, 0])
                tn = running_CM[1][1]
                tp = running_CM[0][0]
                fp = running_CM[1][0]
                fn = running_CM[0][1]                    
                '''
                if phase == 'train':
                    loss.backward()
                    optimizer.step()
                
            running_loss += loss.item() * inputs_labels.size(0)
            running_corrects += torch.sum(prediction == inputs_labels.data)
            
            list_labels = inputs_labels.tolist()
            list_preds = preds.tolist()
            running_auc_label += list_labels
            running_auc_preds += list_preds
          
            
          
        if phase == 'train':
            exp_lr_scheduler.step()
            
        epoch_loss = running_loss / dataset_sizes[phase]
        epoch_acc = running_corrects.double() / dataset_sizes[phase]
        
        # auc roc
        list_labels = torch.tensor(running_auc_label)
        list_preds = torch.tensor(running_auc_preds)
        running_auc_score = roc_auc_score(list_labels.cpu(), list_preds.cpu())
        y_auroc[epoch] = running_auc_score
        
        torch.save(model.state_dict(), savepath + f'/{savename}' + f'Epoch{epoch+1}' + '_weights.pth')

        
        print('{} Loss : {:.4f} Acc : {:.4f}'.format(phase, epoch_loss, epoch_acc))
        #print(inputs_labels)
        #print(preds)
        print('Epoch AUROC : ', running_auc_score)
        
        if phase == 'val' and running_auc_score > best_auroc:
            best_epoch = epoch+1
            best_auroc = running_auc_score
            best_accuracy = epoch_acc
            #torch.save(model.state_dict(), savepath + f'/{savename}' +'_weights.pth')
            #pth_name = f'/{savename}' +'_weights.pth'
    

t.toc() # end time
trainingTime = t.tocvalue()

print('\n best epoch : {}   best acc : {:.4f}'.format(best_epoch, best_accuracy), file = f)
print('best AUROC : {}'.format(best_auroc), file = f)
print('Whole training time : {}'.format(trainingTime), file = f)
print('\n', file = f)
 

 ## Result AUROC plot
x = list(range(1, n_epochs+1)) # x = epoch
plt.figure(figsize = (10, 10))
plt.plot(x, y_auroc, '-')
plt.plot(best_epoch, best_auroc, 'o')
plt.xlabel('Epoch')
plt.ylabel('AUROC score')
plt.savefig(savepath + '/AUROC_' + f'{savename}.png')
plt.show    
     

wr = csv.writer(cf)
wr.writerow(['Auroc'])
for q in range(len(y_auroc)):
    wr.writerow([y_auroc[q]])


f.close()
cf.close()
































