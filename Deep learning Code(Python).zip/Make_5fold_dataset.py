import os
from sklearn.model_selection import KFold


savename = 'EEG'
savename_2 = 'GSR'

# Making Log folder
from datetime import datetime
now = datetime.now()
print("Today Now : ", now.date())

path = '/home/gnsruatkfkd/FutureBrain5/SubCode/StressDataset/EEG'
path_2 = '/home/gnsruatkfkd/FutureBrain5/SubCode/StressDataset/GSR'


# Making 1 - 5 Fold folder 
for q in range(1, 6):    
    if not os.path.isdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold'):
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold')
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold' + '/Train')
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold' + '/Train/Normal')
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold' + '/Train/Stress')
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold' + '/Test')
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold' + '/Test/Normal')
        os.mkdir(path + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold' + '/Test/Stress')

# Making 1 - 5 Fold folder 
for q in range(1, 6):    
    if not os.path.isdir(path_2 + f'/{now.date()}_' + f'{savename}' + f'_{q}Fold'):
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold')
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold' + '/Train')
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold' + '/Train/Normal')
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold' + '/Train/Stress')
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold' + '/Test')
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold' + '/Test/Normal')
        os.mkdir(path_2 + f'/{now.date()}_' + f'{savename_2}' + f'_{q}Fold' + '/Test/Stress')

    
    
savepath = path + f'/{now.date()}_' + f'{savename}'
savepath_2 = path_2 + f'/{now.date()}_' + f'{savename_2}'



kfold = KFold(n_splits = 5, random_state = None, shuffle = True)


## Time calculate
from pytictoc import TicToc
t = TicToc()
t.tic() #start time

## Make dataset
Subject_list = list(range(1, 31)) # 30 subjects
Normal_data_path = 'StressDataset/EEG/Normal/'
Stress_data_path = 'StressDataset/EEG/Stress/'

Normal_data_path_2 = 'StressDataset/GSR/Normal/'
Stress_data_path_2 = 'StressDataset/GSR/Stress/'


import glob
import shutil

for fold, (idx_train, idx_test) in enumerate(kfold.split(Subject_list)):
    
    ########################################################## EEG
    Normal_train_img_list = [] # dataset reset
    Stress_train_img_list = []
    Normal_test_img_list = []
    Stress_test_img_list = []
    
    # Make train list (train_img_list, train_label_list)
    for k in range(len(idx_train)):
        tmp_file_list = glob.glob(f"{Normal_data_path}/{idx_train[k]+1}_*.jpg")
        tmp_file2_list = glob.glob(f"{Stress_data_path}/{idx_train[k]+1}_*.jpg") 
                
        Normal_train_img_list = Normal_train_img_list + tmp_file_list # train_NormalData        
        Stress_train_img_list = Stress_train_img_list + tmp_file2_list # train_StessData
    
    # Normal Train
    file_name = []
    for k in range(len(Normal_train_img_list)):
        tmp_name = Normal_train_img_list[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Normal_train_img_list)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath + f'_{fold+1}Fold' + '/Train/Normal/'
        shutil.copy(src + f'{Normal_train_img_list[k]}', dir + f'{file_name[k]}')
        
    # Stress Train
    file_name = []
    for k in range(len(Stress_train_img_list)):
        tmp_name = Stress_train_img_list[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Stress_train_img_list)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath + f'_{fold+1}Fold' + '/Train/Stress/'
        shutil.copy(src + f'{Stress_train_img_list[k]}', dir + f'{file_name[k]}')
        
        
    # Make test list (test_img_list, test_label_list)
    for k in range(len(idx_test)):
        tmp_file3_list = glob.glob(f"{Normal_data_path}/{idx_test[k]+1}_*.jpg")
        tmp_file4_list = glob.glob(f"{Stress_data_path}/{idx_test[k]+1}_*.jpg") 
                
        Normal_test_img_list = Normal_test_img_list + tmp_file3_list # train_NormalData        
        Stress_test_img_list = Stress_test_img_list + tmp_file4_list # train_StessData
        
    # Normal Test
    file_name = []
    for k in range(len(Normal_test_img_list)):
        tmp_name = Normal_test_img_list[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Normal_test_img_list)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath + f'_{fold+1}Fold' + '/Test/Normal/'
        shutil.copy(src + f'{Normal_test_img_list[k]}', dir + f'{file_name[k]}')
        
    # Stress Test
    file_name = []
    for k in range(len(Stress_test_img_list)):
        tmp_name = Stress_test_img_list[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Stress_test_img_list)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath + f'_{fold+1}Fold' + '/Test/Stress/'
        shutil.copy(src + f'{Stress_test_img_list[k]}', dir + f'{file_name[k]}')
        
        
        
    ########################################################## GSR
    Normal_train_img_list_2 = [] # dataset reset
    Stress_train_img_list_2 = []
    Normal_test_img_list_2 = []
    Stress_test_img_list_2 = []
    
    # Make train list (train_img_list, train_label_list)FutureBrain5
    for k in range(len(idx_train)):
        tmp_file_list_2 = glob.glob(f"{Normal_data_path_2}/{idx_train[k]+1}_*.jpg")
        tmp_file2_list_2 = glob.glob(f"{Stress_data_path_2}/{idx_train[k]+1}_*.jpg") 
                
        Normal_train_img_list_2 = Normal_train_img_list_2 + tmp_file_list_2 # train_NormalData        
        Stress_train_img_list_2 = Stress_train_img_list_2 + tmp_file2_list_2 # train_StessData
    
    # Normal Train
    file_name = []
    for k in range(len(Normal_train_img_list_2)):
        tmp_name = Normal_train_img_list_2[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Normal_train_img_list_2)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath_2 + f'_{fold+1}Fold' + '/Train/Normal/'
        shutil.copy(src + f'{Normal_train_img_list_2[k]}', dir + f'{file_name[k]}')
        
    # Stress Train
    file_name = []
    for k in range(len(Stress_train_img_list_2)):
        tmp_name = Stress_train_img_list_2[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Stress_train_img_list_2)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath_2 + f'_{fold+1}Fold' + '/Train/Stress/'
        shutil.copy(src + f'{Stress_train_img_list_2[k]}', dir + f'{file_name[k]}')
        
        
    # Make test list (test_img_list, test_label_list)
    for k in range(len(idx_test)):
        tmp_file3_list_2 = glob.glob(f"{Normal_data_path_2}/{idx_test[k]+1}_*.jpg")
        tmp_file4_list_2 = glob.glob(f"{Stress_data_path_2}/{idx_test[k]+1}_*.jpg") 
                
        Normal_test_img_list_2 = Normal_test_img_list_2 + tmp_file3_list_2 # train_NormalData        
        Stress_test_img_list_2 = Stress_test_img_list_2 + tmp_file4_list_2 # train_StessData
        
    # Normal Test
    file_name = []
    for k in range(len(Normal_test_img_list_2)):
        tmp_name = Normal_test_img_list_2[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Normal_test_img_list_2)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath_2 + f'_{fold+1}Fold' + '/Test/Normal/'
        shutil.copy(src + f'{Normal_test_img_list_2[k]}', dir + f'{file_name[k]}')
        
    # Stress Test
    file_name = []
    for k in range(len(Stress_test_img_list_2)):
        tmp_name = Stress_test_img_list_2[k]
        tmp_name = tmp_name[25:]
        tmp_name = tmp_name.split()
        file_name = file_name + tmp_name
    # Save Normal train data set
    for k in range(len(Stress_test_img_list_2)):
        src = '/home/gnsruatkfkd/FutureBrain5/SubCode/'
        dir = savepath_2 + f'_{fold+1}Fold' + '/Test/Stress/'
        shutil.copy(src + f'{Stress_test_img_list_2[k]}', dir + f'{file_name[k]}')








